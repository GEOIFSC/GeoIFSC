"""
Serviço para upload de raster para PostGIS.
"""

import os
import shutil
import subprocess
import threading
from pathlib import Path
from typing import List, Optional
from datetime import datetime

from PyQt5.QtCore import QObject, pyqtSignal

from .raster_upload_params import RasterUploadParams, UploadProgress


class RasterUploaderService(QObject):
    """Serviço para upload de raster para PostGIS."""
    
    progress_updated = pyqtSignal(int)
    file_upload_started = pyqtSignal(str)
    file_upload_success = pyqtSignal(str)
    file_upload_error = pyqtSignal(str, str)
    upload_completed = pyqtSignal()
    log_message = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self._is_cancelled = False
        self._current_process: Optional[subprocess.Popen] = None
        self._upload_thread: Optional[threading.Thread] = None
    
    def find_raster2pgsql(self) -> Optional[str]:
        """Localiza o executável raster2pgsql."""
        # Tenta localizar via PATH
        raster2pgsql_path = shutil.which("raster2pgsql")
        if raster2pgsql_path:
            return raster2pgsql_path
        
        # Caminhos possíveis no Windows
        possible_paths = [
            r"C:\Program Files\PostgreSQL\17\bin\raster2pgsql.exe",
            r"C:\Program Files\PostgreSQL\16\bin\raster2pgsql.exe",
            r"C:\Program Files\PostgreSQL\15\bin\raster2pgsql.exe",
            r"C:\Program Files\PostgreSQL\14\bin\raster2pgsql.exe",
            r"C:\Program Files\PostgreSQL\13\bin\raster2pgsql.exe",
            r"C:\Program Files (x86)\PostgreSQL\17\bin\raster2pgsql.exe",
            r"C:\Program Files (x86)\PostgreSQL\16\bin\raster2pgsql.exe",
            r"C:\Program Files (x86)\PostgreSQL\15\bin\raster2pgsql.exe",
        ]
        
        for path in possible_paths:
            if os.path.isfile(path):
                return path
        
        return None
    
    def find_psql(self) -> Optional[str]:
        """Localiza o executável psql."""
        # Tenta localizar via PATH
        psql_path = shutil.which("psql")
        if psql_path:
            return psql_path
        
        # Caminhos possíveis no Windows
        possible_paths = [
            r"C:\Program Files\PostgreSQL\17\bin\psql.exe",
            r"C:\Program Files\PostgreSQL\16\bin\psql.exe",
            r"C:\Program Files\PostgreSQL\15\bin\psql.exe",
            r"C:\Program Files\PostgreSQL\14\bin\psql.exe",
            r"C:\Program Files\PostgreSQL\13\bin\psql.exe",
            r"C:\Program Files (x86)\PostgreSQL\17\bin\psql.exe",
            r"C:\Program Files (x86)\PostgreSQL\16\bin\psql.exe",
            r"C:\Program Files (x86)\PostgreSQL\15\bin\psql.exe",
        ]
        
        for path in possible_paths:
            if os.path.isfile(path):
                return path
        
        return None
    
    def _log(self, message: str):
        """Emite mensagem de log com timestamp."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_message = f"[{timestamp}] {message}"
        self.log_message.emit(formatted_message)
    
    def upload_rasters(self, params: RasterUploadParams):
        """Inicia upload de rasters em thread separada."""
        if self._upload_thread and self._upload_thread.is_alive():
            self._log("Upload já está em andamento")
            return
        
        self._is_cancelled = False
        self._upload_thread = threading.Thread(
            target=self._upload_rasters_worker,
            args=(params,)
        )
        self._upload_thread.daemon = True
        self._upload_thread.start()
    
    def cancel_upload(self):
        """Cancela o upload em andamento."""
        self._is_cancelled = True
        if self._current_process:
            try:
                self._current_process.terminate()
                self._log("Upload cancelado pelo usuário")
            except Exception as e:
                self._log(f"Erro ao cancelar processo: {e}")
    
    def _upload_rasters_worker(self, params: RasterUploadParams):
        """Worker thread para upload de rasters."""
        raster2pgsql_path = self.find_raster2pgsql()
        psql_path = self.find_psql()
        
        if not raster2pgsql_path:
            self._log("ERRO: raster2pgsql não encontrado")
            self.upload_completed.emit()
            return
        
        if not psql_path:
            self._log("ERRO: psql não encontrado")
            self.upload_completed.emit()
            return
        
        self._log(f"Iniciando upload de {len(params.raster_files)} arquivos")
        self._log(f"Usando raster2pgsql: {raster2pgsql_path}")
        self._log(f"Usando psql: {psql_path}")
        
        total_files = len(params.raster_files)
        
        for i, raster_file in enumerate(params.raster_files):
            if self._is_cancelled:
                self._log("Upload cancelado")
                break
            
            # Calcula progresso
            progress = int((i / total_files) * 100)
            self.progress_updated.emit(progress)
            
            # Nome da tabela baseado no basename do arquivo
            file_name = Path(raster_file).stem
            table_name = f"{params.table_name_prefix}{file_name}" if params.table_name_prefix else file_name
            
            self.file_upload_started.emit(raster_file)
            self._log(f"Enviando {file_name} → {table_name}")
            
            try:
                success = self._upload_single_raster(
                    raster_file, table_name, params, raster2pgsql_path, psql_path
                )
                
                if success:
                    self.file_upload_success.emit(raster_file)
                    self._log(f"✓ {file_name} enviado com sucesso")
                else:
                    self.file_upload_error.emit(raster_file, "Falha no upload")
                    self._log(f"✗ Falha ao enviar {file_name}")
                    
            except Exception as e:
                error_msg = str(e)
                self.file_upload_error.emit(raster_file, error_msg)
                self._log(f"✗ Erro ao enviar {file_name}: {error_msg}")
        
        # Progresso final
        if not self._is_cancelled:
            self.progress_updated.emit(100)
            self._log("Upload concluído")
        
        self.upload_completed.emit()
    
    def _upload_single_raster(self, raster_file: str, table_name: str, 
                            params: RasterUploadParams, raster2pgsql_path: str, 
                            psql_path: str) -> bool:
        """Faz upload de um único arquivo raster."""
        try:
            # Comando raster2pgsql
            raster2pgsql_cmd = [
                raster2pgsql_path,
                "-s", str(params.srid),
                "-t", "auto",  # Tile size automático
            ]
            
            if params.overwrite:
                raster2pgsql_cmd.append("-d")  # Drop table
            else:
                raster2pgsql_cmd.append("-a")  # Append
            
            if params.use_index:
                raster2pgsql_cmd.append("-I")  # Create index
            
            if params.use_compression:
                raster2pgsql_cmd.append("-C")  # Compress
            
            raster2pgsql_cmd.extend([
                raster_file,
                f"{params.connection.schema}.{table_name}"
            ])
            
            # Comando psql
            psql_cmd = [
                psql_path,
                "-h", params.connection.host,
                "-p", str(params.connection.port),
                "-U", params.connection.username,
                "-d", params.connection.database,
                "-q"  # Quiet mode
            ]
            
            # Variáveis de ambiente
            env = os.environ.copy()
            env["PGPASSWORD"] = params.connection.password
            
            # Executa raster2pgsql | psql usando subprocess.run
            self._log(f"Executando: {' '.join(raster2pgsql_cmd)} | {' '.join(psql_cmd)}")
            
            # Primeiro executa raster2pgsql
            raster2pgsql_result = subprocess.run(
                raster2pgsql_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            )
            
            if raster2pgsql_result.returncode != 0:
                self._log(f"Falha no raster2pgsql ({raster2pgsql_result.returncode}): {raster2pgsql_result.stderr}")
                return False
            
            # Depois executa psql com a saída do raster2pgsql
            psql_result = subprocess.run(
                psql_cmd,
                input=raster2pgsql_result.stdout,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            )
            
            # Verifica resultado
            if psql_result.returncode == 0:
                self._log(f"Upload concluído: {psql_result.stdout}")
                return True
            else:
                self._log(f"Falha no upload ({psql_result.returncode}): {psql_result.stderr}")
                return False
                
        except Exception as e:
            self._log(f"Erro inesperado no upload de {raster_file}: {e}")
            return False
