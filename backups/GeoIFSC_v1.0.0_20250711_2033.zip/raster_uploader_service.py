"""
Serviço para upload de raster para PostGIS.
"""

import os
import shutil
import subprocess
import threading
from pathlib import Path
from typing import List, Optional
from datetime import datetime

from PyQt5.QtCore import QObject, pyqtSignal

from .raster_upload_params import RasterUploadParams, UploadProgress


class RasterUploaderService(QObject):
    """Serviço para upload de raster para PostGIS."""
    
    progress_updated = pyqtSignal(int)
    file_upload_started = pyqtSignal(str)
    file_upload_success = pyqtSignal(str)
    file_upload_error = pyqtSignal(str, str)
    upload_completed = pyqtSignal()
    log_message = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self._is_cancelled = False
        self._current_process: Optional[subprocess.Popen] = None
        self._upload_thread: Optional[threading.Thread] = None
    
    def find_raster2pgsql(self) -> Optional[str]:
        """Localiza o executável raster2pgsql."""
        # Tenta localizar via PATH
        raster2pgsql_path = shutil.which("raster2pgsql")
        if raster2pgsql_path:
            return raster2pgsql_path
        
        # Caminhos possíveis no Windows
        possible_paths = [
            r"C:\Program Files\PostgreSQL\17\bin\raster2pgsql.exe",
            r"C:\Program Files\PostgreSQL\16\bin\raster2pgsql.exe",
            r"C:\Program Files\PostgreSQL\15\bin\raster2pgsql.exe",
            r"C:\Program Files\PostgreSQL\14\bin\raster2pgsql.exe",
            r"C:\Program Files\PostgreSQL\13\bin\raster2pgsql.exe",
            r"C:\Program Files (x86)\PostgreSQL\17\bin\raster2pgsql.exe",
            r"C:\Program Files (x86)\PostgreSQL\16\bin\raster2pgsql.exe",
            r"C:\Program Files (x86)\PostgreSQL\15\bin\raster2pgsql.exe",
        ]
        
        for path in possible_paths:
            if os.path.isfile(path):
                return path
        
        return None
    
    def find_psql(self) -> Optional[str]:
        """Localiza o executável psql."""
        # Tenta localizar via PATH
        psql_path = shutil.which("psql")
        if psql_path:
            return psql_path
        
        # Caminhos possíveis no Windows
        possible_paths = [
            r"C:\Program Files\PostgreSQL\17\bin\psql.exe",
            r"C:\Program Files\PostgreSQL\16\bin\psql.exe",
            r"C:\Program Files\PostgreSQL\15\bin\psql.exe",
            r"C:\Program Files\PostgreSQL\14\bin\psql.exe",
            r"C:\Program Files\PostgreSQL\13\bin\psql.exe",
            r"C:\Program Files (x86)\PostgreSQL\17\bin\psql.exe",
            r"C:\Program Files (x86)\PostgreSQL\16\bin\psql.exe",
            r"C:\Program Files (x86)\PostgreSQL\15\bin\psql.exe",
        ]
        
        for path in possible_paths:
            if os.path.isfile(path):
                return path
        
        return None
    
    def _log(self, message: str):
        """Emite mensagem de log com timestamp."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_message = f"[{timestamp}] {message}"
        self.log_message.emit(formatted_message)
    
    def upload_rasters(self, params: RasterUploadParams):
        """Inicia upload de rasters em thread separada."""
        if self._upload_thread and self._upload_thread.is_alive():
            self._log("Upload já está em andamento")
            return
        
        self._is_cancelled = False
        self._upload_thread = threading.Thread(
            target=self._upload_rasters_worker,
            args=(params,)
        )
        self._upload_thread.daemon = True
        self._upload_thread.start()
    
    def cancel_upload(self):
        """Cancela o upload em andamento."""
        self._is_cancelled = True
        if self._current_process:
            try:
                self._current_process.terminate()
                self._log("Upload cancelado pelo usuário")
            except Exception as e:
                self._log(f"Erro ao cancelar processo: {e}")
    
    def _upload_rasters_worker(self, params: RasterUploadParams):
        """Worker thread para upload de rasters."""
        raster2pgsql_path = self.find_raster2pgsql()
        psql_path = self.find_psql()
        
        if not raster2pgsql_path:
            self._log("ERRO: raster2pgsql não encontrado")
            self.upload_completed.emit()
            return
        
        if not psql_path:
            self._log("ERRO: psql não encontrado")
            self.upload_completed.emit()
            return
        
        self._log(f"Iniciando upload de {len(params.raster_files)} arquivos")
        self._log(f"Usando raster2pgsql: {raster2pgsql_path}")
        self._log(f"Usando psql: {psql_path}")
        
        total_files = len(params.raster_files)
        
        for i, raster_file in enumerate(params.raster_files):
            if self._is_cancelled:
                self._log("Upload cancelado")
                break
            
            # Calcula progresso
            progress = int((i / total_files) * 100)
            self.progress_updated.emit(progress)
            
            # Nome da tabela baseado no basename do arquivo
            file_name = Path(raster_file).stem
            table_name = f"{params.table_name_prefix}{file_name}" if params.table_name_prefix else file_name
            
            self.file_upload_started.emit(raster_file)
            self._log(f"Enviando {file_name} → {table_name}")
            
            try:
                success = self._upload_single_raster(
                    raster_file, table_name, params, raster2pgsql_path, psql_path
                )
                
                if success:
                    self.file_upload_success.emit(raster_file)
                    self._log(f"✓ {file_name} enviado com sucesso")
                else:
                    self.file_upload_error.emit(raster_file, "Falha no upload")
                    self._log(f"✗ Falha ao enviar {file_name}")
                    
            except Exception as e:
                error_msg = str(e)
                self.file_upload_error.emit(raster_file, error_msg)
                self._log(f"✗ Erro ao enviar {file_name}: {error_msg}")
        
        # Progresso final
        if not self._is_cancelled:
            self.progress_updated.emit(100)
            self._log("Upload concluído")
        
        self.upload_completed.emit()
    
    def _upload_single_raster(self, raster_file: str, table_name: str, 
                            params: RasterUploadParams, raster2pgsql_path: str, 
                            psql_path: str) -> bool:
        """Faz upload de um único arquivo raster com controle de substituição."""
        try:
            # Determina nome final da tabela considerando substituição
            final_table_name = self._resolve_table_name(table_name, params)
            full_table_name = f"{params.connection.schema}.{final_table_name}"
            
            self._log(f"Iniciando upload: {raster_file} → {full_table_name}")
            
            # Comando raster2pgsql com flags de criação/recriação
            raster2pgsql_cmd = [
                raster2pgsql_path,
                "-c",  # Create table (always create new)
                "-d",  # Drop table if exists (recreate)
                "-s", str(params.srid),
                "-t", "auto",  # Tile size automático
            ]
            
            if params.use_index:
                raster2pgsql_cmd.append("-I")  # Create index
            
            if params.use_compression:
                raster2pgsql_cmd.append("-C")  # Compress
            
            raster2pgsql_cmd.extend([
                raster_file,
                full_table_name
            ])
            
            # Comando psql com commit explícito
            psql_cmd = [
                psql_path,
                "-h", params.connection.host,
                "-p", str(params.connection.port),
                "-U", params.connection.username,
                "-d", params.connection.database,
                "-q",  # Quiet mode
                "-c", "COMMIT;"  # Commit explícito após execução
            ]
            
            # Variáveis de ambiente para autenticação
            env = os.environ.copy()
            env["PGPASSWORD"] = params.connection.password
            
            self._log(f"Executando raster2pgsql: {' '.join(raster2pgsql_cmd)}")
            
            # Executa raster2pgsql
            raster2pgsql_result = subprocess.run(
                raster2pgsql_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            )
            
            if raster2pgsql_result.returncode != 0:
                self._log(f"Falha no raster2pgsql ({raster2pgsql_result.returncode}): {raster2pgsql_result.stderr}")
                return False
            
            self._log(f"raster2pgsql executado com sucesso")
            
            # Executa psql com SQL gerado + commit
            sql_with_commit = raster2pgsql_result.stdout + "\nCOMMIT;"
            
            psql_exec_cmd = [
                psql_path,
                "-h", params.connection.host,
                "-p", str(params.connection.port),
                "-U", params.connection.username,
                "-d", params.connection.database,
                "-q"  # Quiet mode
            ]
            
            self._log(f"Executando psql com commit explícito")
            
            psql_result = subprocess.run(
                psql_exec_cmd,
                input=sql_with_commit,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            )
            
            # Verifica resultado final
            if psql_result.returncode == 0:
                self._log(f"Upload concluído com sucesso: {final_table_name}")
                if psql_result.stdout.strip():
                    self._log(f"Saída psql: {psql_result.stdout.strip()}")
                return True
            else:
                self._log(f"Falha no psql ({psql_result.returncode}): {psql_result.stderr}")
                return False
                
        except Exception as e:
            self._log(f"Erro inesperado no upload de {raster_file}: {e}")
            return False
    
    def _resolve_table_name(self, base_name: str, params: RasterUploadParams) -> str:
        """Resolve nome final da tabela considerando flag de substituição."""
        if params.overwrite:
            # Se overwrite=True, usa nome original (será recriada com -d)
            self._log(f"Modo sobrescrita ativado: {base_name} será recriada")
            return base_name
        
        # Se overwrite=False, verifica se tabela existe e incrementa sufixo
        return self._get_unique_table_name(base_name, params)
    
    def _get_unique_table_name(self, base_name: str, params: RasterUploadParams) -> str:
        """Gera nome único incrementando sufixo numérico se necessário."""
        try:
            # Comando para verificar se tabela existe
            check_cmd = [
                self.find_psql(),
                "-h", params.connection.host,
                "-p", str(params.connection.port),
                "-U", params.connection.username,
                "-d", params.connection.database,
                "-t",  # Tuple only output
                "-c", f"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='{params.connection.schema}' AND table_name='{base_name}';"
            ]
            
            env = os.environ.copy()
            env["PGPASSWORD"] = params.connection.password
            
            result = subprocess.run(
                check_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            )
            
            if result.returncode == 0:
                count = int(result.stdout.strip())
                if count == 0:
                    # Tabela não existe, usa nome original
                    self._log(f"Tabela {base_name} não existe, usando nome original")
                    return base_name
                else:
                    # Tabela existe, busca próximo sufixo disponível
                    counter = 1
                    while counter <= 999:  # Limite de segurança
                        candidate_name = f"{base_name}_{counter}"
                        check_cmd[7] = f"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='{params.connection.schema}' AND table_name='{candidate_name}';"
                        
                        result = subprocess.run(check_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env, creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
                        
                        if result.returncode == 0 and int(result.stdout.strip()) == 0:
                            self._log(f"Nome único encontrado: {candidate_name}")
                            return candidate_name
                        
                        counter += 1
                    
                    # Se chegou aqui, usa timestamp como fallback
                    import time
                    timestamp_suffix = int(time.time())
                    fallback_name = f"{base_name}_{timestamp_suffix}"
                    self._log(f"Usando fallback com timestamp: {fallback_name}")
                    return fallback_name
            else:
                self._log(f"Erro ao verificar existência da tabela, usando nome original: {result.stderr}")
                return base_name
                
        except Exception as e:
            self._log(f"Erro na resolução do nome da tabela: {e}, usando nome original")
            return base_name
